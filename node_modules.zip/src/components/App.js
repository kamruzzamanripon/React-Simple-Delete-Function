import React, {Component} from 'react';
import './App.css';
import First from './First/First'
import Count from './counter/counter'

class App extends Component {
  state = {
    persons: [
      {name: 'syed kamruzzamanripon', email: 'ripon@gmail.com', address: 'kamlapur, dhaka'},
      {name: 'syed kamruzzamsanripon', email: 'ripodn@gmail.com', address: 'kamlapdur, dhaka'},
      {name: 'syed kamruzzamavsdnripon', email: 'ridon@gmail.com', address: 'kamladpur, dhaka'}
    ]
  }

  render(){
    return (
    
      <div className="App">
         {this.state.persons.map( (people, index)=>{
            return <First
                    key = {index}
                    name = {people.name}
                    email = {people.email}
                    address = {people.address} />
         } )}
  
        
      </div>
      
    );
  }
}

export default App;
